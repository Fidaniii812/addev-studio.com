# Si ta publikosh këtë faqe (Vercel - metoda e rekomanduar)

1. Krijo një repo të re në GitHub dhe shto këto file (index.html, privacy.html, contact.html, styles.css, script.js).
2. Regjistrohu në https://vercel.com dhe lidhi GitHub-in.
3. Në Vercel, klik "New Project" → import repo-n tënd.
4. Pasi të përpunohet, Vercel do të publikojë faqen dhe do të japë një URL si: `your-repo-name.vercel.app`.

Alternativa: Netlify (drag & drop të folder) ose GitHub Pages.

## Pikat e rëndësishme për AdSense
- Faqja duhet të jetë publike dhe me përmbajtje origjinale.
- Shtoji një faqe Privacy Policy dhe Contact (krijuar më sipër).
- Apliko në https://adsense.google.com duke dhënë URL-në e publikuar.
- Ndiq udhëzimet e Google për të vendosur kodin e reklamave pas aprovimit.

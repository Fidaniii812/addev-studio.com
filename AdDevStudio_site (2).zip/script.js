document.getElementById('year').textContent = new Date().getFullYear();
// shembull: vendos këtu tracking për Analytics ose AdSense (kur aprovohet)
